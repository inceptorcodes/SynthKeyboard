# synth

This code is used in the Code-It-Yourself sound synthesizer videos on the onelonecoder.com blog
